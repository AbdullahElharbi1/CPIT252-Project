package MVC;
import Proxy.*;
import Observor.*;

import java.util.Scanner;

public class AppointmentSystem {

    public static void main(String[] args) {
        // Give values to the MVC Components
        
        // View handles user things
        AppointmentView view = new AppointmentView();
        // Observer handles things
        AppointmentNotifier notifier = new AppointmentNotifier(); 
        // Proxy to check doctor availability
        DoctorAvailability doctorAvailability = new DoctorAvailabilityProxy(true); 
        // Controller to handle things
        AppointmentController controller = new AppointmentController(view, notifier, doctorAvailability); 
        // get the user name
        System.out.print("Please enter your name: ");
        Scanner scanner = new Scanner(System.in);
        String patientName = scanner.nextLine();

        // Create a new Patient instance and register as an observer
        Patient patient = new Patient(patientName);
        notifier.addObserver(patient);

        boolean running = true; // Control variable for the application loop

        // Main application loop
        while (running) {
            // Display the menu and get the user's choice
            view.displayMenu();
            int choice = view.getMenuChoice();

            // Handle user's choice using a switch-case structure
            switch (choice) {
                case 1:
                    // If the user chooses to book an appointment
                    if (doctorAvailability.isAvailable()) { // Check if doctors are available
                        int doctorChoice = view.getDoctorChoice(); // Get user's choice of doctor
                        // Assign doctor name and time based on user input
                        String doctorName = doctorChoice == 1 ? "Dr. Faisal" : "Dr. Ahmed";
                        String time = doctorChoice == 1 ? "10:00 AM" : "11:00 AM";
                        // Book the appointment using the controller
                        controller.bookAppointment(patient.getName(), doctorName, time);
                    } else {
                        // If no doctors are available
                        view.displayMessage("No doctors are available at this time.");
                    }
                    break;

                case 2:
                    // If the user chooses to cancel an appointment
                    controller.cancelAppointment();
                    break;

                case 3:
                    // If the user chooses to view appointment details
                    String appointmentDetails = controller.getAppointmentDetails(); // Get details from the controller
                    view.showAppointmentDetails(appointmentDetails); // Display the details
                    break;

                case 4:
                    // If the user chooses to exit the application
                    running = false; // End the loop
                    view.displayMessage("Thank you for using the Appointment Booking System!");
                    break;

                default:
                    // Handle invalid menu choices
                    view.displayMessage("Invalid choice. Please try again.");
                    break;
            }
        }

        // Close the scanner when the application ends
        scanner.close();
    }
}
