package MVC;

import java.util.Scanner;

public class AppointmentView {

    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        System.out.println("\nWelcome to the Appointment Booking System!");
        System.out.println("1. Book an Appointment");
        System.out.println("2. Cancel Appointment");
        System.out.println("3. View Appointment Details");
        System.out.println("4. Exit");
        System.out.print("Choose an option: ");
    }

    public int getMenuChoice() {
        return scanner.nextInt();
    }

    public int getDoctorChoice() {
        System.out.println("\nAvailable Doctors:");
        System.out.println("1. Dr. Faisal at 10:00 AM");
        System.out.println("2. Dr. Ahmed at 11:00 AM");
        System.out.print("Select a doctor and time: ");
        return scanner.nextInt();
    }

    public void displayMessage(String message) {
        System.out.println(message);
    }

    public void showAppointmentDetails(String details) {
        System.out.println("Appointment Details: " + details);
    }
}
