package MVC;

import Proxy.*;
import Observor.*;

public class AppointmentController {

    private AppointmentView view;
    private AppointmentNotifier notifier;
    private DoctorAvailability doctorAvailability;

    public AppointmentController(AppointmentView view, AppointmentNotifier notifier, DoctorAvailability doctorAvailability) {
        this.view = view;
        this.notifier = notifier;
        this.doctorAvailability = doctorAvailability;
    }

    public String getAppointmentDetails() {
        if (PatientAppointmentModel.hasAppointment()) {
            return PatientAppointmentModel.getDetails();
        } else {
            return "No appointment found.";
        }
    }

    public void bookAppointment(String patientName, String doctorName, String time) {
        if (!PatientAppointmentModel.hasAppointment()) {
            if (doctorAvailability.isAvailable()) {
                PatientAppointmentModel model = PatientAppointmentModel.bookAppointment(patientName, doctorName, time);
                notifier.notifyObservers("Your appointment is confirmed with Dr. " + doctorName + " at " + time);
                view.showAppointmentDetails(model.getDetails());
            } else {
                view.displayMessage("Doctor is not available. Please try another time.");
            }
        } else {
            view.displayMessage("You already have an appointment. Cancel it before booking a new one.");
        }
    }

    public void cancelAppointment() {
        if (PatientAppointmentModel.hasAppointment()) {
            PatientAppointmentModel.cancelAppointment();
            notifier.notifyObservers("Your appointment has been canceled.");
        } else {
            view.displayMessage("No appointment to cancel.");
        }
    }
}
