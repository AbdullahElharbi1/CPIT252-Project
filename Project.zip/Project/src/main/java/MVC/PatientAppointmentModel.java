
package MVC;
import Proxy.*;
import Observor.*;

public class PatientAppointmentModel {

    private static PatientAppointmentModel instance;
    private String patientName;
    private String doctorName;
    private String time;

    private PatientAppointmentModel(String patientName, String doctorName, String time) {
        this.patientName = patientName;
        this.doctorName = doctorName;
        this.time = time;
    }

    public static PatientAppointmentModel bookAppointment(String patientName, String doctorName, String time) {
        if (instance == null) {
            instance = new PatientAppointmentModel(patientName, doctorName, time);
            System.out.println("Appointment booked successfully!");
        } else {
            System.out.println("You already have an appointment. Cancel it before booking a new one.");
        }
        return instance;
    }

    public static void cancelAppointment() {
        if (instance != null) {
            System.out.println("Appointment with Dr. " + instance.doctorName + " at " + instance.time + " has been cancelled.");
            instance = null;
        } else {
            System.out.println("No appointment to cancel.");
        }
    }

    public static String getDetails() {
        return instance != null ? "Patient: " + instance.patientName + ", Doctor: " + instance.doctorName + ", Time: " + instance.time : "No appointment found.";
    }

    public static boolean hasAppointment() {
        return instance != null;
    }
}
