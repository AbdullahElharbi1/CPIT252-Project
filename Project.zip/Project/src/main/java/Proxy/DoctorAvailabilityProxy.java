/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proxy;

/**
 *
 * @author Admin
 */
public class DoctorAvailabilityProxy implements DoctorAvailability {

    public RealDoctorAvailability realAvailability;
    public Boolean cachedAvailability;

    public DoctorAvailabilityProxy(boolean available) {
        this.realAvailability = new RealDoctorAvailability(available);
    }

    @Override
    public boolean isAvailable() {
        if (cachedAvailability == null) {
            cachedAvailability = realAvailability.isAvailable();
        } else {
            System.out.println("Using cached availability status...");
        }
        return cachedAvailability;
    }
}
